﻿using ClothBazar.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ClothBazar.Web.HomeModelViews
{
    public class HomeModelView
    {
        public List<Category> FeaturedCategories
        {
            get; set;
        }
        
    }
}